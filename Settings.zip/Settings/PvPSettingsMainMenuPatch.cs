﻿using System.Reflection;
using HarmonyLib;
using Kitchen;
using Kitchen.Modules;
using UnityEngine;

namespace TestMod.Team.TeamChecks
{
    [HarmonyPatch(typeof(MainMenu), "Setup")]
    internal class PvPSettingsMainMenuPatch
    {
        private static MethodInfo _addButtonMethod;
        private static MethodInfo _mainMenuSetupMethod;
        private static FieldInfo _containerField;
        private static FieldInfo _moduleListField;

        [HarmonyPrefix]
        private static bool Prefix(MainMenu __instance)
        {
            if (_addButtonMethod == null)
            {
                _addButtonMethod = AccessTools.Method(typeof(Menu<MenuAction>), "AddButton");
                _mainMenuSetupMethod = AccessTools.Method(typeof(MainMenu), "Setup");
                _containerField = AccessTools.Field(typeof(Menu<MenuAction>), "Container");
                _moduleListField = AccessTools.Field(typeof(Menu<MenuAction>), "ModuleList");
            }

            _addButtonMethod.Invoke(__instance, new object[]
            {
                "PvP Settings",
                (System.Action<int>)((int playerId) =>
                {
                    OpenPvPSettings(__instance, playerId);
                }),
                0,
                1,
                0.2f,
            });
            return true;
        }

        public static void OpenPvPSettings(MainMenu mainMenu, int playerId)
        {
            var container = (Transform)_containerField.GetValue(mainMenu);
            var moduleList = (ModuleList)_moduleListField.GetValue(mainMenu);

            moduleList.Clear();

            var menu = new PvPSettingsMenu<MenuAction>(container, moduleList, mainMenu);
            menu.Setup(playerId);
        }

        public static void ReturnToMainMenu(MainMenu mainMenu, int playerId)
        {
            var moduleList = (ModuleList)_moduleListField.GetValue(mainMenu);
            moduleList.Clear();

            _mainMenuSetupMethod.Invoke(mainMenu, new object[] { playerId });
        }
    }
}