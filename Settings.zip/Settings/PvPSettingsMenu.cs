﻿using UnityEngine;
using Kitchen.Modules;
using Kitchen;
using System.Collections.Generic;
using KitchenLib;

namespace TestMod.Team.TeamChecks
{
    public class PvPSettingsMenu<T> : KLMenu<T>
    {
        private static readonly List<bool> boolValues = new List<bool> { false, true };
        private static readonly List<string> boolLabels = new List<string> { "Off", "On" };

        private static readonly List<int> strikeValues = new List<int> { 1, 2, 3, 4, 5 };
        private static readonly List<string> strikeLabels = new List<string> { "1", "2", "3", "4", "5" };

        private MainMenu _parentMainMenu;

        public PvPSettingsMenu(Transform container, ModuleList module_list, MainMenu parentMainMenu) : base(container, module_list)
        {
            _parentMainMenu = parentMainMenu;
        }

        public override void Setup(int player_id)
        {
            addShowPopupSelect();
            addStrikesSelect();

            New<SpacerElement>();
            AddButton("Colors", delegate
            {
                ModuleList.Clear();
                var submenu = new PvPTestSubmenu<T>(Container, ModuleList, _parentMainMenu);
                submenu.Setup(player_id);
            });

            addBackButton(player_id);
        }

        private void addShowPopupSelect()
        {
            Option<bool> option = new Option<bool>(boolValues, PvPModSettings.GetShowRestartPopup(), boolLabels);

            AddLabel("Show Restart Popup");
            AddInfo("If On, players confirm each restart via a popup. If Off, restarts happen immediately.");
            AddSelect(option);

            option.OnChanged += delegate (object _, bool value)
            {
                PvPModSettings.SetShowRestartPopup(value);
            };
        }

        private void addStrikesSelect()
        {
            Option<int> option = new Option<int>(strikeValues, PvPModSettings.GetStrikesBeforeElimination(), strikeLabels);

            AddLabel("Strikes Before Elimination");
            AddInfo("How many table failures a team can have before elimination.");
            AddSelect(option);

            option.OnChanged += delegate (object _, int value)
            {
                PvPModSettings.SetStrikesBeforeElimination(value);
            };
        }

        private void addBackButton(int player_id)
        {
            New<SpacerElement>();
            AddButton(Localisation["MENU_BACK_SETTINGS"], delegate
            {
                PvPSettingsMainMenuPatch.ReturnToMainMenu(_parentMainMenu, player_id);
            });
        }
    }

    public class PvPTestSubmenu<T> : KLMenu<T>
    {
        private MainMenu _parentMainMenu;

        public PvPTestSubmenu(Transform container, ModuleList module_list, MainMenu parentMainMenu) : base(container, module_list)
        {
            _parentMainMenu = parentMainMenu;
        }

        public override void Setup(int player_id)
        {
            AddLabel("This is a test submenu");

            New<SpacerElement>();
            AddButton(Localisation["MENU_BACK_SETTINGS"], delegate
            {
                ModuleList.Clear();
                var settingsMenu = new PvPSettingsMenu<T>(Container, ModuleList, _parentMainMenu);
                settingsMenu.Setup(player_id);
            });
        }
    }
}