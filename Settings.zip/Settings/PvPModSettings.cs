﻿using Kitchen;
using KitchenMods;

namespace TestMod.Team.TeamChecks
{
    public static class PvPModSettings
    {
        private static readonly Pref ShowRestartPopupPref = new Pref(Mod.MOD_GUID, nameof(ShowRestartPopupPref));
        private static readonly Pref StrikesBeforeEliminationPref = new Pref(Mod.MOD_GUID, nameof(StrikesBeforeEliminationPref));

        private const bool DefaultShowRestartPopup = false;
        private const int DefaultStrikesBeforeElimination = 3;

        public static bool GetShowRestartPopup() => Preferences.Get<bool>(ShowRestartPopupPref);
        public static void SetShowRestartPopup(bool value) => Preferences.Set<bool>(ShowRestartPopupPref, value);

        public static int GetStrikesBeforeElimination() => Preferences.Get<int>(StrikesBeforeEliminationPref);
        public static void SetStrikesBeforeElimination(int value) => Preferences.Set<int>(StrikesBeforeEliminationPref, value);

        public static void RegisterPreferences()
        {
            Preferences.AddPreference<bool>(new BoolPreference(ShowRestartPopupPref, DefaultShowRestartPopup));
            Preferences.AddPreference<int>(new IntPreference(StrikesBeforeEliminationPref, DefaultStrikesBeforeElimination));
            Preferences.Load();
        }
    }
}